package com.empresa.model.enums;

public enum StaffStatus {
    ACTIVO,
    INACTIVO,
    VACACIONES,
    LICENCIA
}